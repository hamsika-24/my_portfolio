import { useInView } from 'react-intersection-observer';
import { ReactNode } from 'react';

interface RevealProps {
  children: ReactNode;
  direction?: 'left' | 'right' | 'up' | 'down';
  delay?: number;
  className?: string;
}

export const Reveal = ({ children, direction = 'up', delay = 0, className = '' }: RevealProps) => {
  const [ref, inView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });

  const getDirectionClasses = () => {
    switch (direction) {
      case 'left':
        return inView ? 'translate-x-0 opacity-100' : '-translate-x-20 opacity-0';
      case 'right':
        return inView ? 'translate-x-0 opacity-100' : 'translate-x-20 opacity-0';
      case 'down':
        return inView ? 'translate-y-0 opacity-100' : '-translate-y-20 opacity-0';
      case 'up':
      default:
        return inView ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0';
    }
  };

  return (
    <div
      ref={ref}
      className={`transition-all duration-1000 ease-out ${getDirectionClasses()} ${className}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
};
