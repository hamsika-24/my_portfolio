import { useEffect, useState } from 'react';
import { ArrowUp } from 'lucide-react';

export const CustomCursor = () => {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isPointer, setIsPointer] = useState(false);

  useEffect(() => {
    const mouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
      
      const target = e.target as HTMLElement;
      // Check if the target or any of its parents are clickable
      const isClickable = target.tagName === 'A' || target.tagName === 'BUTTON' || 
                          target.closest('a') !== null || target.closest('button') !== null ||
                          window.getComputedStyle(target).cursor === 'pointer';
      setIsPointer(isClickable);
    };

    window.addEventListener('mousemove', mouseMove);
    return () => window.removeEventListener('mousemove', mouseMove);
  }, []);

  return (
    <>
      <div
        className="fixed top-0 left-0 pointer-events-none z-50 hidden md:flex items-center justify-center mix-blend-difference transition-transform duration-100 ease-out"
        style={{
          transform: `translate(${mousePosition.x - 12}px, ${mousePosition.y - 12}px) scale(${isPointer ? 1.5 : 1}) rotate(${isPointer ? 45 : 0}deg)`,
        }}
      >
        <ArrowUp 
          size={24} 
          className={isPointer ? "text-pink-500" : "text-indigo-500"} 
          style={{ transform: 'rotate(-45deg)' }} // Initial rotation to point top-left like a cursor
        />
      </div>
      
      {/* Trail effect */}
      <div
        className="fixed top-0 left-0 w-4 h-4 rounded-full pointer-events-none z-40 hidden md:block opacity-50 transition-all duration-150 ease-out"
        style={{
          transform: `translate(${mousePosition.x - 8}px, ${mousePosition.y - 8}px)`,
          backgroundColor: isPointer ? '#ec4899' : '#6366f1',
        }}
      />
    </>
  );
};
