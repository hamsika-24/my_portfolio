import { Heart } from 'lucide-react';

export const Footer = () => {
  return (
    <footer className="py-8 bg-white dark:bg-gray-950 border-t border-gray-200 dark:border-gray-800">
      <div className="max-w-7xl mx-auto px-4 text-center">
        <p className="flex items-center justify-center text-gray-600 dark:text-gray-400 mb-2">
          Made with <Heart size={16} className="text-red-500 mx-1 fill-current" /> by Hamsika
        </p>
        <p className="text-sm text-gray-500 dark:text-gray-500">
          © {new Date().getFullYear()} Medipalli Satya Sreepradha Hamsika. All rights reserved.
        </p>
      </div>
    </footer>
  );
};
