import { GraduationCap, BookOpen, User } from 'lucide-react';
import { Reveal } from '../ui/Reveal';

export const About = () => {
  return (
    <section id="about" className="py-20 bg-white dark:bg-gray-900 px-4 overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <Reveal direction="up">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4">About Me</h2>
            <div className="w-24 h-1.5 bg-gradient-to-r from-purple-600 to-pink-600 mx-auto rounded-full" />
          </div>
        </Reveal>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <Reveal direction="left" className="relative">
            <div className="aspect-square rounded-2xl overflow-hidden bg-gradient-to-br from-purple-500 to-pink-500 p-1 shadow-2xl rotate-3 hover:rotate-0 transition-transform duration-500">
              <div className="w-full h-full bg-white dark:bg-gray-800 rounded-xl flex flex-col items-center justify-center p-8 text-center">
                 <div className="w-24 h-24 bg-purple-100 dark:bg-purple-900/30 rounded-full flex items-center justify-center mb-6 text-purple-600 dark:text-purple-400">
                   <User size={48} />
                 </div>
                 <p className="text-xl font-medium text-gray-800 dark:text-white mb-4">
                   "Passionate about leveraging technology to solve real-world problems."
                 </p>
                 <p className="text-gray-600 dark:text-gray-400 italic">
                   — Medipalli Satya Sreepradha Hamsika
                 </p>
              </div>
            </div>
            {/* Decorative elements */}
            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-purple-200 dark:bg-purple-900/30 rounded-full -z-10 blur-2xl" />
            <div className="absolute -top-6 -left-6 w-40 h-40 bg-pink-200 dark:bg-pink-900/30 rounded-full -z-10 blur-2xl" />
          </Reveal>

          <Reveal direction="right">
            <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-6 bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-pink-500">
              A Journey of Learning & Growth
            </h3>
            
            <p className="text-lg text-gray-600 dark:text-gray-300 mb-8 leading-relaxed">
              I am a dedicated Computer Science Engineering student with a strong foundation in programming and a keen interest in Artificial Intelligence and Machine Learning. My goal is to build innovative solutions that make a positive impact.
            </p>
            
            <div className="space-y-6">
              <div className="flex gap-4 p-4 rounded-xl bg-gray-50 dark:bg-gray-800/50 hover:bg-white dark:hover:bg-gray-800 shadow-sm hover:shadow-md transition-all border border-transparent hover:border-purple-100 dark:hover:border-purple-900">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center text-purple-600 dark:text-purple-400">
                  <GraduationCap size={24} />
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-gray-900 dark:text-white">Education</h4>
                  <p className="text-gray-700 dark:text-gray-300 font-medium">B.Tech CSE</p>
                  <p className="text-gray-600 dark:text-gray-400">KL University Hyderabad</p>
                  <p className="text-sm text-purple-600 dark:text-purple-400 font-medium">2024 - 2028</p>
                </div>
              </div>

              <div className="flex gap-4 p-4 rounded-xl bg-gray-50 dark:bg-gray-800/50 hover:bg-white dark:hover:bg-gray-800 shadow-sm hover:shadow-md transition-all border border-transparent hover:border-pink-100 dark:hover:border-pink-900">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-pink-100 dark:bg-pink-900/30 flex items-center justify-center text-pink-600 dark:text-pink-400">
                  <BookOpen size={24} />
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-gray-900 dark:text-white">Current Focus</h4>
                  <p className="text-gray-600 dark:text-gray-400">
                    Expanding knowledge in Full Stack Development and exploring AI/ML applications.
                  </p>
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
};
