import { ArrowDown, FileText } from 'lucide-react';
import { TypeAnimation } from 'react-type-animation';
import { Reveal } from '../ui/Reveal';

export const Hero = () => {
  return (
    <section id="home" className="min-h-screen flex flex-col justify-center items-center relative overflow-hidden bg-gray-50 dark:bg-gray-950 px-4">
      {/* Background decorations */}
      <div className="absolute top-20 left-10 w-64 h-64 bg-purple-400/20 dark:bg-purple-600/10 rounded-full blur-3xl animate-pulse" />
      <div className="absolute bottom-20 right-10 w-96 h-96 bg-pink-400/20 dark:bg-pink-600/10 rounded-full blur-3xl animate-pulse delay-700" />
      
      <div className="text-center z-10 max-w-4xl">
        <Reveal direction="down">
          <span className="inline-block py-1 px-3 rounded-full bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-300 text-sm font-semibold mb-4 border border-purple-200 dark:border-purple-800">
            Portfolio
          </span>
          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight text-gray-900 dark:text-white mb-6">
            Hi, I'm <br />
            <span className="bg-gradient-to-r from-purple-600 via-pink-500 to-red-500 bg-clip-text text-transparent">
              Medipalli Satya Sreepradha Hamsika
            </span>
          </h1>
        </Reveal>

        <Reveal direction="up" delay={200}>
          <div className="text-xl md:text-3xl text-gray-600 dark:text-gray-300 mb-8 max-w-2xl mx-auto font-medium h-12">
            I am a{' '}
            <TypeAnimation
              sequence={[
                'Developer',
                1000,
                'Engineer',
                1000,
                'Problem Solver',
                1000,
                'Tech Enthusiast',
                1000,
              ]}
              wrapper="span"
              speed={50}
              className="text-purple-600 dark:text-purple-400 font-bold"
              repeat={Infinity}
            />
          </div>
        </Reveal>

        <Reveal direction="up" delay={400}>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="#projects"
              className="px-8 py-3 rounded-full bg-purple-600 text-white font-medium hover:bg-purple-700 transition-all shadow-lg shadow-purple-500/30 hover:shadow-purple-500/50 hover:-translate-y-1"
            >
              View Projects
            </a>
            <a
              href="/resume.txt"
              target="_blank"
              rel="noopener noreferrer"
              className="px-8 py-3 rounded-full bg-white dark:bg-gray-800 text-gray-900 dark:text-white border border-gray-200 dark:border-gray-700 font-medium hover:bg-gray-50 dark:hover:bg-gray-700 transition-all flex items-center justify-center gap-2 hover:-translate-y-1"
            >
              <FileText size={18} />
              View Resume
            </a>
          </div>
        </Reveal>
      </div>

      <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce text-gray-400 dark:text-gray-500">
        <ArrowDown size={32} />
      </div>
    </section>
  );
};
