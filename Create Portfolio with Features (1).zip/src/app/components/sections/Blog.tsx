import { Calendar, User, ArrowRight } from 'lucide-react';
import { Reveal } from '../ui/Reveal';

const blogPosts = [
  {
    id: 1,
    title: "The Future of AI in Everyday Life",
    excerpt: "Exploring how Artificial Intelligence is reshaping our daily routines and what to expect in the next decade.",
    date: "Oct 15, 2024",
    author: "Hamsika",
    category: "Technology",
    readTime: "5 min read"
  },
  {
    id: 2,
    title: "Mastering React Hooks",
    excerpt: "A deep dive into useEffect, useState, and custom hooks for cleaner and more efficient code.",
    date: "Nov 02, 2024",
    author: "Hamsika",
    category: "Development",
    readTime: "8 min read"
  },
  {
    id: 3,
    title: "Why Upskilling is Crucial",
    excerpt: "In a rapidly evolving tech landscape, continuous learning is the key to staying relevant and successful.",
    date: "Dec 10, 2024",
    author: "Hamsika",
    category: "Career",
    readTime: "4 min read"
  }
];

export const Blog = () => {
  return (
    <section id="blog" className="py-20 bg-white dark:bg-gray-900 px-4">
      <div className="max-w-7xl mx-auto">
        <Reveal direction="up">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4">Latest from Blog</h2>
            <div className="w-24 h-1.5 bg-gradient-to-r from-purple-600 to-pink-600 mx-auto rounded-full" />
          </div>
        </Reveal>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {blogPosts.map((post, index) => (
            <Reveal
              key={post.id}
              direction="up"
              delay={index * 100}
              className="bg-gray-50 dark:bg-gray-800 rounded-2xl p-6 shadow-md hover:shadow-xl transition-all hover:-translate-y-2 border border-gray-100 dark:border-gray-700 flex flex-col h-full group"
            >
              <div className="flex justify-between items-center mb-4 text-xs text-gray-500 dark:text-gray-400">
                <span className="flex items-center gap-1 font-medium"><Calendar size={14} /> {post.date}</span>
                <span className="px-3 py-1 bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-300 rounded-full font-bold text-[10px] uppercase tracking-wider">{post.category}</span>
              </div>
              
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3 group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors cursor-pointer">
                {post.title}
              </h3>
              
              <p className="text-gray-600 dark:text-gray-400 text-sm mb-6 flex-grow leading-relaxed">
                {post.excerpt}
              </p>
              
              <div className="flex items-center justify-between pt-4 border-t border-gray-200 dark:border-gray-700 mt-auto">
                <div className="flex items-center text-sm font-medium text-gray-700 dark:text-gray-300">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center text-white text-xs mr-2">
                    <User size={14} />
                  </div>
                  {post.author}
                </div>
                <button className="text-purple-600 dark:text-purple-400 hover:translate-x-1 transition-transform">
                  <ArrowRight size={18} />
                </button>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
};
