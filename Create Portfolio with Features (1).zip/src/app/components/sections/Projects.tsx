import { useState } from 'react';
import { ExternalLink, Github } from 'lucide-react';
import { Reveal } from '../ui/Reveal';

// Project Data
const allProjects = [
  {
    id: 1,
    title: "Swwiy Swiz",
    category: "Frontend Development",
    description: "A skill swap platform designed to connect individuals who want to exchange knowledge and expertise. Built with modern frontend technologies.",
    image: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1740&q=80",
    tags: ["React", "Tailwind CSS", "Vite"]
  },
  {
    id: 2,
    title: "SLAS (Sign Language Analyser)",
    category: "AI & Machine Learning",
    description: "An innovative AIML project that interprets sign language gestures into text/speech, bridging the communication gap.",
    image: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1740&q=80",
    tags: ["Python", "TensorFlow", "OpenCV"]
  },
  {
    id: 3,
    title: "Women's E-Commerce",
    category: "Data Analysis",
    description: "A data-driven e-commerce platform analysis focusing on trends in women's fashion and shopping behaviors.",
    image: "https://images.unsplash.com/photo-1483985988355-763728e1935b?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1740&q=80",
    tags: ["Data Analytics", "Visualization", "E-commerce"]
  },
  {
    id: 4,
    title: "Data Dashboard Pro",
    category: "Data Analysis",
    description: "Interactive dashboard for visualizing complex datasets with real-time filtering capabilities.",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1740&q=80",
    tags: ["PowerBI", "SQL", "Excel"]
  },
  {
    id: 5,
    title: "AI Chat Assistant",
    category: "AI/ML",
    description: "A smart chatbot capable of handling customer queries with natural language processing.",
    image: "https://images.unsplash.com/photo-1531746790731-6c087fecd65a?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1740&q=80",
    tags: ["NLP", "Python", "API Integration"]
  }
];

export const Projects = () => {
  const [showAll, setShowAll] = useState(false);
  const displayedProjects = showAll ? allProjects : allProjects.slice(0, 3);

  return (
    <section id="projects" className="py-20 bg-gray-50 dark:bg-gray-950 px-4">
      <div className="max-w-7xl mx-auto">
        <Reveal direction="up">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4">Featured Projects</h2>
            <div className="w-24 h-1.5 bg-gradient-to-r from-purple-600 to-pink-600 mx-auto rounded-full" />
          </div>
        </Reveal>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {displayedProjects.map((project, index) => (
            <Reveal
              key={project.id}
              direction="up"
              delay={index * 100}
              className="bg-white dark:bg-gray-900 rounded-xl overflow-hidden shadow-lg border border-gray-100 dark:border-gray-800 flex flex-col h-full transition-transform duration-300 hover:-translate-y-2 hover:shadow-2xl"
            >
              <div className="h-48 overflow-hidden relative group">
                <img 
                  src={project.image} 
                  alt={project.title} 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-between p-4">
                   <div className="flex gap-2">
                     <button className="p-2 bg-white rounded-full text-gray-900 hover:bg-purple-600 hover:text-white transition-colors">
                       <Github size={18} />
                     </button>
                     <button className="p-2 bg-white rounded-full text-gray-900 hover:bg-purple-600 hover:text-white transition-colors">
                       <ExternalLink size={18} />
                     </button>
                   </div>
                </div>
                <div className="absolute top-4 right-4 bg-purple-600/90 backdrop-blur-sm text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                  {project.category}
                </div>
              </div>
              <div className="p-6 flex flex-col flex-grow">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">{project.title}</h3>
                <p className="text-gray-600 dark:text-gray-400 text-sm mb-4 flex-grow leading-relaxed">
                  {project.description}
                </p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tags.map(tag => (
                    <span key={tag} className="text-xs px-2 py-1 bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 rounded-md font-medium border border-gray-200 dark:border-gray-700">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal direction="up" delay={200}>
          <div className="text-center mt-12">
            <button
              onClick={() => setShowAll(!showAll)}
              className="px-8 py-3 rounded-full bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold shadow-lg hover:shadow-xl transition-all active:scale-95 hover:-translate-y-1"
            >
              {showAll ? 'Show Less' : 'View All Projects'}
            </button>
          </div>
        </Reveal>
      </div>
    </section>
  );
};
