import { Award, Code2, Globe } from 'lucide-react';
import { Reveal } from '../ui/Reveal';

const certifications = [
  {
    title: "Global Certificate",
    issuer: "Automation Anywhere",
    date: "2024",
    icon: Code2,
    description: "Certified in Robotic Process Automation (RPA) essentials, automating repetitive tasks with efficiency."
  },
  {
    title: "Full Stack Development",
    issuer: "Udemy",
    date: "2024",
    icon: Globe,
    description: "Comprehensive course on modern web development technologies including React, Node.js, and Databases."
  },
  {
    title: "Internship Certificate",
    issuer: "EduSkills",
    date: "2024",
    icon: Award,
    description: "Hands-on experience with industry-standard tools and practices, contributing to real-world projects."
  }
];

export const Experience = () => {
  return (
    <section id="experience" className="py-20 bg-gray-50 dark:bg-gray-950 px-4">
      <div className="max-w-7xl mx-auto">
        <Reveal direction="up">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4">Experience & Certifications</h2>
            <div className="w-24 h-1.5 bg-gradient-to-r from-purple-600 to-pink-600 mx-auto rounded-full" />
          </div>
        </Reveal>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {certifications.map((cert, index) => (
            <Reveal
              key={index}
              direction="up"
              delay={index * 200}
              className="group bg-white dark:bg-gray-900 p-8 rounded-2xl shadow-lg hover:shadow-2xl border border-gray-100 dark:border-gray-800 transition-all duration-300 hover:-translate-y-2 relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-purple-100 dark:bg-purple-900/10 rounded-bl-full -mr-8 -mt-8 transition-all group-hover:bg-purple-200 dark:group-hover:bg-purple-800/20" />
              
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white mb-6 shadow-lg transform group-hover:rotate-6 transition-transform">
                <cert.icon size={32} />
              </div>
              
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">{cert.title}</h3>
              <p className="text-purple-600 dark:text-purple-400 font-bold mb-1 uppercase tracking-wide text-sm">{cert.issuer}</p>
              <p className="text-sm text-gray-500 dark:text-gray-500 mb-4 font-mono">{cert.date}</p>
              <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                {cert.description}
              </p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
};
