import { ArrowRight } from 'lucide-react';

export const CTA = () => {
  return (
    <section className="py-20 bg-white dark:bg-gray-900 px-4">
      <div className="max-w-4xl mx-auto">
        <div 
          className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-3xl p-12 text-center text-white shadow-2xl relative overflow-hidden animate-in fade-in zoom-in-95 duration-700 view-transition"
        >
          {/* Decorative circles */}
          <div className="absolute top-0 left-0 w-64 h-64 bg-white/10 rounded-full -translate-x-1/2 -translate-y-1/2 blur-2xl" />
          <div className="absolute bottom-0 right-0 w-64 h-64 bg-black/10 rounded-full translate-x-1/2 translate-y-1/2 blur-2xl" />

          <h2 className="text-3xl md:text-5xl font-bold mb-6 relative z-10">Get In Touch</h2>
          <p className="text-lg md:text-xl text-purple-100 mb-8 max-w-2xl mx-auto relative z-10">
            Have an idea or want to collaborate? Check out my work or drop me a message!
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center relative z-10">
            <a 
              href="#projects" 
              className="px-8 py-3 bg-white text-purple-600 rounded-full font-bold hover:bg-gray-100 transition-colors inline-flex items-center justify-center group"
            >
              View My Projects
              <ArrowRight size={20} className="ml-2 group-hover:translate-x-1 transition-transform" />
            </a>
            <a 
              href="#contact" 
              className="px-8 py-3 bg-transparent border-2 border-white text-white rounded-full font-bold hover:bg-white/10 transition-colors"
            >
              Contact Me
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};
