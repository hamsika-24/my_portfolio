import { 
  FaPython, FaJava, FaReact, FaNodeJs, FaGitAlt, FaGithub, FaLinux, FaFigma, FaJs 
} from 'react-icons/fa';
import { 
  SiC, SiMysql, SiCanva, SiTensorflow 
} from 'react-icons/si';
import { VscVscode } from 'react-icons/vsc';
import { Reveal } from '../ui/Reveal';

const skillCategories = [
  {
    title: "Programming Languages",
    skills: [
      { name: "C", icon: SiC, color: "text-blue-500" },
      { name: "Java", icon: FaJava, color: "text-red-500" },
      { name: "Python", icon: FaPython, color: "text-yellow-500" },
      { name: "JavaScript", icon: FaJs, color: "text-yellow-400" },
    ]
  },
  {
    title: "Web & ML Technologies",
    skills: [
      { name: "React JS", icon: FaReact, color: "text-cyan-400" },
      { name: "Node JS", icon: FaNodeJs, color: "text-green-500" },
      { name: "Machine Learning", icon: SiTensorflow, color: "text-orange-500" }, // Using TensorFlow as proxy for ML
    ]
  },
  {
    title: "Tools & Database",
    skills: [
      { name: "Git", icon: FaGitAlt, color: "text-red-600" },
      { name: "GitHub", icon: FaGithub, color: "text-gray-800 dark:text-white" },
      { name: "MySQL", icon: SiMysql, color: "text-blue-600" },
      { name: "VS Code", icon: VscVscode, color: "text-blue-500" },
      { name: "Linux", icon: FaLinux, color: "text-yellow-600" },
    ]
  },
  {
    title: "Design & Creative",
    skills: [
      { name: "Figma", icon: FaFigma, color: "text-purple-500" },
      { name: "Canva", icon: SiCanva, color: "text-cyan-600" },
    ]
  }
];

export const Skills = () => {
  return (
    <section id="skills" className="py-20 bg-white dark:bg-gray-900 px-4 overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <Reveal direction="up">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4 bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-pink-600">
              Technical Skills
            </h2>
            <p className="text-gray-600 dark:text-gray-400 mb-2 max-w-2xl mx-auto">
              A collection of technologies I've mastered on my journey.
            </p>
            <div className="w-24 h-1.5 bg-gradient-to-r from-purple-600 to-pink-600 mx-auto rounded-full mt-4" />
          </div>
        </Reveal>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {skillCategories.map((category, catIndex) => (
            <Reveal 
              key={catIndex} 
              direction={catIndex % 2 === 0 ? "left" : "right"} 
              delay={catIndex * 100}
              className="bg-gray-50 dark:bg-gray-800/50 p-6 rounded-2xl border border-gray-100 dark:border-gray-700 hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
            >
              <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-6 border-b border-gray-200 dark:border-gray-700 pb-2">
                {category.title}
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {category.skills.map((skill, index) => (
                  <div 
                    key={index}
                    className="flex flex-col items-center justify-center p-4 bg-white dark:bg-gray-800 rounded-xl shadow-sm hover:shadow-md transition-all group"
                  >
                    <skill.icon className={`text-4xl mb-3 ${skill.color} group-hover:scale-110 transition-transform duration-300`} />
                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300 text-center">
                      {skill.name}
                    </span>
                  </div>
                ))}
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
};
