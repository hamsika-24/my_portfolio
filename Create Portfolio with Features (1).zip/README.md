
  # Create Portfolio with Features

  This is a code bundle for Create Portfolio with Features. The original project is available at https://www.figma.com/design/drq1bo34Vn23B1piXQOdsi/Create-Portfolio-with-Features.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  